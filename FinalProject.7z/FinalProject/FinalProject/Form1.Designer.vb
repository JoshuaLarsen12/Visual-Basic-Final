﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.lblStartDate = New System.Windows.Forms.Label()
        Me.lblFuture = New System.Windows.Forms.Label()
        Me.lblStartInfo = New System.Windows.Forms.Label()
        Me.lblEndInfo = New System.Windows.Forms.Label()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.nudHourStartDate = New System.Windows.Forms.NumericUpDown()
        Me.nudDayStartDate = New System.Windows.Forms.NumericUpDown()
        Me.nudMonthStartDate = New System.Windows.Forms.NumericUpDown()
        Me.nudYearStartDate = New System.Windows.Forms.NumericUpDown()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.txtNumOfHours = New System.Windows.Forms.TextBox()
        Me.txtNumOfDays = New System.Windows.Forms.TextBox()
        CType(Me.nudHourStartDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudDayStartDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudMonthStartDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudYearStartDate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblInstructions
        '
        Me.lblInstructions.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstructions.Location = New System.Drawing.Point(12, 9)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(563, 41)
        Me.lblInstructions.TabIndex = 0
        Me.lblInstructions.Text = "Enter a start date and how much time you want to pass, I will cacluate the future" &
    " date!"
        Me.lblInstructions.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblStartDate
        '
        Me.lblStartDate.AutoSize = True
        Me.lblStartDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStartDate.Location = New System.Drawing.Point(18, 50)
        Me.lblStartDate.Name = "lblStartDate"
        Me.lblStartDate.Size = New System.Drawing.Size(89, 24)
        Me.lblStartDate.TabIndex = 1
        Me.lblStartDate.Text = "Start Date"
        '
        'lblFuture
        '
        Me.lblFuture.AutoSize = True
        Me.lblFuture.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFuture.Location = New System.Drawing.Point(399, 50)
        Me.lblFuture.Name = "lblFuture"
        Me.lblFuture.Size = New System.Drawing.Size(107, 24)
        Me.lblFuture.TabIndex = 2
        Me.lblFuture.Text = "How Long?"
        '
        'lblStartInfo
        '
        Me.lblStartInfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStartInfo.Location = New System.Drawing.Point(11, 97)
        Me.lblStartInfo.Name = "lblStartInfo"
        Me.lblStartInfo.Size = New System.Drawing.Size(78, 110)
        Me.lblStartInfo.TabIndex = 3
        Me.lblStartInfo.Text = "Hour: Day: Month: Year:"
        '
        'lblEndInfo
        '
        Me.lblEndInfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEndInfo.Location = New System.Drawing.Point(398, 90)
        Me.lblEndInfo.Name = "lblEndInfo"
        Me.lblEndInfo.Size = New System.Drawing.Size(87, 53)
        Me.lblEndInfo.TabIndex = 4
        Me.lblEndInfo.Text = "Hours: Days:"
        '
        'lblResult
        '
        Me.lblResult.BackColor = System.Drawing.Color.Gainsboro
        Me.lblResult.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResult.Location = New System.Drawing.Point(17, 207)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(558, 147)
        Me.lblResult.TabIndex = 9
        Me.lblResult.Text = "Result:"
        Me.lblResult.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(500, 357)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 10
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'nudHourStartDate
        '
        Me.nudHourStartDate.Location = New System.Drawing.Point(95, 97)
        Me.nudHourStartDate.Maximum = New Decimal(New Integer() {24, 0, 0, 0})
        Me.nudHourStartDate.Name = "nudHourStartDate"
        Me.nudHourStartDate.Size = New System.Drawing.Size(84, 20)
        Me.nudHourStartDate.TabIndex = 11
        '
        'nudDayStartDate
        '
        Me.nudDayStartDate.Location = New System.Drawing.Point(95, 123)
        Me.nudDayStartDate.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudDayStartDate.Name = "nudDayStartDate"
        Me.nudDayStartDate.Size = New System.Drawing.Size(84, 20)
        Me.nudDayStartDate.TabIndex = 12
        Me.nudDayStartDate.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'nudMonthStartDate
        '
        Me.nudMonthStartDate.Location = New System.Drawing.Point(95, 149)
        Me.nudMonthStartDate.Maximum = New Decimal(New Integer() {30, 0, 0, 0})
        Me.nudMonthStartDate.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudMonthStartDate.Name = "nudMonthStartDate"
        Me.nudMonthStartDate.Size = New System.Drawing.Size(84, 20)
        Me.nudMonthStartDate.TabIndex = 13
        Me.nudMonthStartDate.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'nudYearStartDate
        '
        Me.nudYearStartDate.Location = New System.Drawing.Point(95, 175)
        Me.nudYearStartDate.Maximum = New Decimal(New Integer() {2025, 0, 0, 0})
        Me.nudYearStartDate.Minimum = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.nudYearStartDate.Name = "nudYearStartDate"
        Me.nudYearStartDate.Size = New System.Drawing.Size(84, 20)
        Me.nudYearStartDate.TabIndex = 14
        Me.nudYearStartDate.Value = New Decimal(New Integer() {2000, 0, 0, 0})
        '
        'btnCalc
        '
        Me.btnCalc.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalc.Location = New System.Drawing.Point(246, 122)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(99, 46)
        Me.btnCalc.TabIndex = 15
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'txtNumOfHours
        '
        Me.txtNumOfHours.Location = New System.Drawing.Point(491, 96)
        Me.txtNumOfHours.Name = "txtNumOfHours"
        Me.txtNumOfHours.Size = New System.Drawing.Size(84, 20)
        Me.txtNumOfHours.TabIndex = 16
        '
        'txtNumOfDays
        '
        Me.txtNumOfDays.Location = New System.Drawing.Point(491, 123)
        Me.txtNumOfDays.Name = "txtNumOfDays"
        Me.txtNumOfDays.Size = New System.Drawing.Size(84, 20)
        Me.txtNumOfDays.TabIndex = 17
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(587, 381)
        Me.Controls.Add(Me.txtNumOfDays)
        Me.Controls.Add(Me.txtNumOfHours)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.nudYearStartDate)
        Me.Controls.Add(Me.nudMonthStartDate)
        Me.Controls.Add(Me.nudDayStartDate)
        Me.Controls.Add(Me.nudHourStartDate)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.lblEndInfo)
        Me.Controls.Add(Me.lblStartInfo)
        Me.Controls.Add(Me.lblFuture)
        Me.Controls.Add(Me.lblStartDate)
        Me.Controls.Add(Me.lblInstructions)
        Me.Name = "frmMain"
        Me.Text = "Date Calculator by Joshua Larsen"
        CType(Me.nudHourStartDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudDayStartDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudMonthStartDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudYearStartDate, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblInstructions As Label
    Friend WithEvents lblStartDate As Label
    Friend WithEvents lblFuture As Label
    Friend WithEvents lblStartInfo As Label
    Friend WithEvents lblEndInfo As Label
    Friend WithEvents lblResult As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents nudHourStartDate As NumericUpDown
    Friend WithEvents nudDayStartDate As NumericUpDown
    Friend WithEvents nudMonthStartDate As NumericUpDown
    Friend WithEvents nudYearStartDate As NumericUpDown
    Friend WithEvents btnCalc As Button
    Friend WithEvents txtNumOfHours As TextBox
    Friend WithEvents txtNumOfDays As TextBox
End Class
