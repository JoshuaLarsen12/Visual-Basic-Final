﻿Public Class frmMain
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim curhour As Integer
        Dim curDay As Integer
        Dim curMonth As Integer
        Dim curYear As Integer

        Dim intNumOfHours As Integer
        Dim intNumOfDays As Integer
        Dim intFebEnd As Integer

        Dim intFuHours As Integer
        Dim intfuDays As Integer
        Dim CanCaluclate As Boolean = True

        curhour = nudHourStartDate.Value
        curDay = nudDayStartDate.Value
        curMonth = nudMonthStartDate.Value
        curYear = nudYearStartDate.Value

        intNumOfHours = txtNumOfHours.Text
        intNumOfDays = txtNumOfDays.Text


        IsLeapYear(curYear, intFebEnd)

        Dim MonthEnds() As Integer = {31, intFebEnd, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}


        CheckInput(curDay, curMonth, MonthEnds, CanCaluclate)
        intFuHours = curhour + intNumOfHours

        intfuDays = curDay + intNumOfDays
        While CanCaluclate

            Do

                If intFuHours > 24 Then
                    intFuHours = intFuHours - 24
                    curDay = curDay + 1
                End If


                If intfuDays > MonthEnds(curMonth - 1) Then
                    intfuDays = intfuDays - MonthEnds(curMonth - 1)
                    curMonth = curMonth + 1
                End If



                If curMonth > 12 Then


                    curYear = curYear + 1
                    curMonth = 1

                    IsLeapYear(curYear, intFebEnd)

                End If


            Loop While intfuDays > MonthEnds(curMonth - 1) And intFuHours > 24


            lblResult.Text = "Result: " & vbNewLine & "Hour: " & intFuHours & vbNewLine & "Date: " & curMonth & "/" & intfuDays & "/" & curYear
            If intfuDays <= MonthEnds(curMonth - 1) And intFuHours <= 24 Then


                CanCaluclate = False

            End If
        End While




    End Sub


    Sub IsLeapYear(ByVal Year As Integer, ByRef FebEnd As Integer)

        Dim boolLeapYear As Boolean

        If Year Mod 4 = 0 Then

            boolLeapYear = True
        Else
            boolLeapYear = False

        End If


        If boolLeapYear Then

            FebEnd = 29
        Else
            FebEnd = 28

        End If
    End Sub

    Sub CheckInput(ByVal dayInput As Integer, ByVal MonthInput As Integer, ByVal MonthEnd() As Integer, ByRef canCalc As Boolean)

        Dim checkday As Boolean

        If MonthInput > 12 Then
            MessageBox.Show("Can't Do that!! Start month needs to be lower!")
            canCalc = False
            checkday = False
        Else
            canCalc = True
            checkday = True
        End If

        If checkday Then

            If dayInput > MonthEnd(MonthInput - 1) Then

                MessageBox.Show("Can't Do that!! To many days for that Month!")

                canCalc = False
            Else

                canCalc = True

            End If

        End If


    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        End
    End Sub
End Class